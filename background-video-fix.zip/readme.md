# Background Video Fix (Mobile)

Extension for mobile Firefox browser that fixes the [YouTube](https://m.youtube.com/) video auto-pause when changing tabs or toggle to another app.
